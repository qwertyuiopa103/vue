<script setup>
import { RouterView } from 'vue-router'
</script>

<template>
  <div>
    <router-view></router-view>
  </div>
</template>

<style scoped>

</style>
