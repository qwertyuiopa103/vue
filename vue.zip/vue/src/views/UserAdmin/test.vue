<script setup>

</script>

<template>
    <div>
        這是測試
    </div>
</template>

<style lang="css" scoped></style>