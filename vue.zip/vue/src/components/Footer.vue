<template>
    <footer id="footer" class="footer light-background">
        <div class="container">
            <div class="row g-0">
                <div class="col-md-6 col-lg-3 mb-3 mb-md-0">
                    <div class="widget">
                        <strong class="widget-heading">訂閱我們</strong>
                        <hr>
                        <ul class="list-unstyled social-icons light mb-3">
                            <li><a href="#"><span class="bi bi-facebook"></span></a></li>
                            <li><a href="#"><span class="bi bi-twitter-x"></span></a></li>
                            <li><a href="#"><span class="bi bi-linkedin"></span></a></li>
                            <li><a href="#"><span class="bi bi-google"></span></a></li>
                            <li><a href="#"><span class="bi bi-google-play"></span></a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3  mb-3  mx-3">
                    <div class="widget">
                        <strong class="widget-heading">聯絡我們</strong>
                        <hr>
                        <ul class="list-unstyled float-start me-5">
                            <strong>連絡電話</strong>
                            <li>00000000</li>
                            <strong>詳細地址</strong>
                            <li>320桃園市中壢區新生路二段421號</li>
                        </ul>

                    </div>
                </div>
                <div class="col-md-6 col-lg-4 pl-lg-5">
                    <div class="widget">
                        <iframe
                            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d57863.05972359!2d121.15579573125001!3d24.985118800000013!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x34682183e7b783c3%3A0xf0ebfba2069b6158!2z6IGW5b635Z-6552j5a246Zmi!5e0!3m2!1szh-TW!2stw!4v1736389958711!5m2!1szh-TW!2stw"
                            width="500" height="300" style="border:0;" allowfullscreen="" loading="lazy"
                            referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>
                </div>
            </div>

            <div class="copyright d-flex flex-column flex-md-row align-items-center justify-content-md-between">
                <p>
                    © <span>Copyright</span>
                    <strong class="px-1 sitename">Active.</strong>
                    <span>All Rights Reserved</span>
                </p>
                <div class="credits">
                    <!-- All the links in the footer should remain intact. -->
                    <!-- You can delete the links only if you've purchased the pro version. -->
                    <!-- Licensing information: https://bootstrapmade.com/license/ -->
                    <!-- Purchase the pro version with working PHP/AJAX contact form: [buy-url] -->
                    Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
                </div>
            </div>
        </div>
    </footer>
</template>

<script setup>
// 如果需要在 Footer 中添加 JavaScript 邏輯，可以在這裡添加
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap-icons/font/bootstrap-icons.css';
</script>
<style scoped></style>